package com.springproject.student;

import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

@Service
public class StudentService {
    private List<Student> students=new ArrayList<>(Arrays.asList(
            new Student(101,"kavitha","arunachalam",LocalDate.now()),
            new Student(102,"saravana","ramanathan",LocalDate.now())
    ));
    public List<Student> getStudents() {
        return students;
    }

    public void addStudents(Student student) {
        students.add(student);
    }
}
