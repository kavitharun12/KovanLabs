package com.springproject.student;

import java.lang.annotation.Annotation;
import java.lang.annotation.ElementType;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Retention;
import java.lang.annotation.Target;

@Target(ElementType.TYPE)
@Retention(RetentionPolicy.RUNTIME)
@interface LogRequest
{
    boolean log() default false;
}

@LogRequest(log=true)
class LoggingRequest
{
    boolean logging;
    public LoggingRequest(boolean logging){this.logging=logging;}
}

public class CustomAnnotation
{
    public static void main(String[] args)
    {
        LoggingRequest obj=new LoggingRequest(true);

        Class c=obj.getClass();
        Annotation an=c.getAnnotation(LogRequest.class);
        LogRequest l=(LogRequest)an;
        System.out.println(l.log());
    }
}
